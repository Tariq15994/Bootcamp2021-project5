import Todo from "./Todo";
declare function addTodo(todo: Todo): Promise<Todo | null>;
export default addTodo;
