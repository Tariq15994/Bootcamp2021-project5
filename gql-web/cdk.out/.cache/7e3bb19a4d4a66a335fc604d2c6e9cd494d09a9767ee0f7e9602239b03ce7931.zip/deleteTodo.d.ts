declare function deleteTodo(todoId: string): Promise<any>;
export default deleteTodo;
