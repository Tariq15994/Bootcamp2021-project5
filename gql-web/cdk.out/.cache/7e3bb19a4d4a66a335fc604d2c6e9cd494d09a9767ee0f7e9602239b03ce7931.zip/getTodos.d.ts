declare function getTodos(): Promise<any>;
export default getTodos;
