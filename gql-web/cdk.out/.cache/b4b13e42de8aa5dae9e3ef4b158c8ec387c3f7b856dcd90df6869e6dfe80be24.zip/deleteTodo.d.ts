declare function deleteTodo(todoId: string): Promise<string | null>;
export default deleteTodo;
